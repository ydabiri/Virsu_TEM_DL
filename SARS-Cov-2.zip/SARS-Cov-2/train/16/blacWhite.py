# from torchsummary import summary
import pandas as pd
import numpy as np
from skimage.io import imread, imsave
from tqdm import tqdm
import matplotlib.pyplot as plt
# %matplotlib inline

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

from skimage.transform import rotate
from skimage.util import random_noise
from skimage.filters import gaussian
from scipy import ndimage

import random
from scipy import ndarray
import skimage as sk
from skimage import transform
from skimage import util
from skimage import exposure
from scipy import ndimage
import os
from PIL import Image
import PIL.ImageOps

rootDir = '/Users/home/Desktop/16'
os.chdir(rootDir)

def rotation(image):
    #a random rotation is applied
    angle = 180
    return sk.transform.rotate(image, angle)

def noise(image):
    return sk.util.random_noise(image)

def flip(image):
    return image[:, ::-1]

# def intensity(image):
#     vMin, vMax = np.percentile(image, (0.2, 99.8))
#     newContrast = exposure.rescale_intensity(image, in_range=(vMin, vMax))
#     return

def invert(image):
    return util.invert(image)


counter = 1
for subdir, dirs, files in os.walk(rootDir):
    for file in files:
        os.chdir(rootDir)
        filePath = subdir + os.sep + file
        filePathNew = '/Users/home/Desktop/15'

        if filePath.endswith('.png'):
          os.chdir(filePathNew)

          # image = sk.io.imread(filePath)
          # image = image.astype(np.uint8)

          image = Image.open(filePath)
          I = np.asarray(PIL.Image.open(filePath))
          print(I)

          # inverted_image = PIL.ImageOps.invert(image)
          #
          # inverted_image.save(filePath)



          counter += 1
